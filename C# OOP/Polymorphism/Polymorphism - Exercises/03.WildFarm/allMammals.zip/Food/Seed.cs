﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm
{
    public class Seed : Food
    {
        public Seed(int amount) : base(amount)
        {
        }
    }
}
