﻿namespace _02.Poly
{
    public class Car:Vehicle
    {
        public Car(double Consumption, double quantity, double tankCapacity) : base(Consumption, quantity, tankCapacity)
        {
        }
    }
}
