﻿namespace _02.Poly
{
    public class Truck:Vehicle
    {
        public Truck(double Consumption, double quantity, double tankCapacity) : base(Consumption, quantity, tankCapacity)
        {
        }
    }
}
