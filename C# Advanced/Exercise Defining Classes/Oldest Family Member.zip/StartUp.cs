﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var family = new Family();
            int x = int.Parse(Console.ReadLine());
            for (int i = 0; i < x; i++)
            {
                var input = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries).ToArray();
                family.AddMember(new Person(input[0],int.Parse(input[1])));
            }

            Console.WriteLine(family.GetOldestMember());

        }
    }
}
