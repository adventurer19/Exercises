﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RawData07
{
    public class Startup
    {
        static void Main(string[] args)
        {
            var list = new List<Car>();
            var number = int.Parse(Console.ReadLine());
            for (int i = 0; i < number; i++)
            {
                var input = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries).ToArray();
                var model = input[0];
                var engineSpeed = int.Parse(input[1]);
                var enginePower = int.Parse(input[2]);
                var cargoWeight = int.Parse(input[3]);
                var cargoType = input[4];
                var cargo = new Cargo(cargoWeight, cargoType);
                var engine = new Engine(engineSpeed, enginePower);
                var tires = new Tiers[]
                {
                    new Tiers(double.Parse(input[5]), int.Parse(input[6])),
                    new Tiers(double.Parse(input[7]), int.Parse(input[8])),
                    new Tiers(double.Parse(input[9]), int.Parse(input[10])),
                    new Tiers(double.Parse(input[11]), int.Parse(input[12])),
                };
                list.Add(new Car(model, engine, cargo, tires));
            }

            string type = Console.ReadLine();
            var filtered = new List<Car>();
            filtered = type == "fragile"
                ? filtered = list.Where(x => x.Cargo.Type == "fragile" && x.Tier.Any(t => t.Pressure < 1))
                    .ToList()
                : filtered = list.Where(t => t.Cargo.Type == "flamable" && t.Engine.Power > 250).ToList();
            foreach (var item in filtered)
            {
                Console.WriteLine(item.Model);
            }

        }
    }
}
