﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RawData07
{
    public class Car
    {
        public string Model { get; set; }
        public Engine Engine { get; set; }
        public Cargo Cargo { get; set; }
        public Tiers[] Tier { get; set; }

        public Car(string model, Engine engine, Cargo cargo, Tiers[] tires)
        {
            Model = model;
            Engine = engine;
            Cargo = cargo;
            Tier = tires;
        }

    }
}
