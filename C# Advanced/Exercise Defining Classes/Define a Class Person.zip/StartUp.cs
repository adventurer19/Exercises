﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var personOne = new Person()
            {
                Name = "Peter",
                Age = 20,
            };
            var personTwo = new Person("George", 18);
            var personThree = new Person("Sam", 43);
        }
    }
}
