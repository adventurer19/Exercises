﻿using System;
using System.Collections.Generic;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var person = new Person();
            var persontwo = new Person(3);
            var person3 = new Person("niki", 2);
            var list = new List<Person>();
            list.Add(person);
            list.Add(persontwo);
            list.Add(person3);
            foreach (var item in list)
            {
                Console.WriteLine($"{item.Name}  age:{item.Age}");
            }
        }
    }
}
