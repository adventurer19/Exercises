﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Date_Modifier
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int x = int.Parse(Console.ReadLine());
            var car = new Car[x];
            for (int i = 0; i < x; i++)
            {
                var input = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries).ToArray();
                var model = input[0];
                var fuelAmount = decimal.Parse(input[1]);
                var fuelConsumptionFor1km = decimal.Parse(input[2]);
                car[i] = new Car(model, fuelAmount, fuelConsumptionFor1km);
            }

            var line = Console.ReadLine();
            while (line!="End")
            {
                var input = line.Split(' ', StringSplitOptions.RemoveEmptyEntries).ToArray();
                var model = input[1];
                var distance = decimal.Parse(input[2]);
                car.Where(x => x.Model == model).ToList().ForEach(x => x.Drive(distance));
                line = Console.ReadLine();
            }

            foreach (var item in car)
            {
                Console.WriteLine(item);
            }
            

        }
    }
}
