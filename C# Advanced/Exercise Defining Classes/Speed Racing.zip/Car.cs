﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Date_Modifier
{
    public class Car
    {
        public string Model { get; set; }
        public decimal FuelAmount { get; set; }
        public decimal FuelConsumptionPerKilometer { get; set; }
        public decimal Travelled { get; set; }

        public Car()
        {
            Travelled = 0;
        }

        public Car(string model, decimal fuelAmount, decimal fuelConsumptionPerKilometer) : this()
        {
            Model = model;
            FuelAmount = fuelAmount;
            FuelConsumptionPerKilometer = fuelConsumptionPerKilometer;
        }

        public void Drive(decimal distance)
        {
            decimal amount = distance * FuelConsumptionPerKilometer;
            if (amount <= FuelAmount)
            {
                FuelAmount -= amount;
                Travelled += distance;
            }
            else
            {
                Console.WriteLine("Insufficient fuel for the drive");
            }
        }

        public override string ToString()
        {
            return $"{Model} {FuelAmount:f2} {Travelled}";
        }
    }
}
