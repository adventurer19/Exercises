﻿namespace Guild
{
    /// <summary>
    /// Your task is to create a repository which stores players by creating the classes described below.
    /// First, write a C# class Player with the following properties:
    /// Name: string
    /// Class: string
    /// Rank: string – "Trial" by default
    /// Description: string – "n/a" by default
    /// 
    /// </summary>
    public class Player
    {
        private string _name;
        private string _class;
        private string _rank = "Trial";
        private string _description = "n/a";

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string Class
        {
            get { return _class; }
            set { _class = value; }
        }

        public string Rank
        {
            get { return _rank; }
            set { _rank = value; }
        }

        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }

        public Player(string aname, string aclass)
        {
            Name = aname;
            Class = aclass;
        }

        public override string ToString()
        {
            return $"Player {Name}: {Class}\nRank: {Rank}\nDescription: {Description}";
        }
    }
}
