﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Guild
{
    public class Guild
    {
        public List<Player> list;

       private int count;

        public int Count
        {
            get { return count; }
            set { count = list.Count; }
        }

        public string Name { get; set; }
        public int Capacity { get; set; }

        public Guild(string name, int capacity)
        {
            Name = name;
            Capacity = capacity;
            list = new List<Player>(Capacity);
        }
      
        public void AddPlayer(Player newPlayer)
        {

            if (!list.Contains(newPlayer) && list.Count < Capacity)
            {
                list.Add(newPlayer);
                 count++;
            }

        }

        public bool RemovePlayer(string newPlayer)
        {
            var currentPlayer = list.Find(x => x.Name == newPlayer);
            
            if (currentPlayer != null)
            {
                list.Remove(currentPlayer);
                return true;
            }

            count--;
            return false;
        }

        public void PromotePlayer(string name)
        {
            var player = list.Find(x => x.Name == name);
            if (player != null && player.Rank != "Member")
            {
                player.Rank = "Member";
            }
        }

        public void DemotePlayer(string name)
        {
            var player = list.Find(x => x.Name == name);
            if (player != null && player.Rank != "Trial")
            {
                player.Rank = "Trial";
            }
        }

        public Player[] KickPlayersByClass(string Aclass)
        {
            var removedPeople = new List<Player>();
            while (list.Find(x => x.Class == Aclass) != null)
            {
                var player = list.Find(x => x.Class == Aclass);
                removedPeople.Add(player);
                list.Remove(player);

            }

            count -= removedPeople.Count;
            return removedPeople.ToArray();
        }

        public string Report()
        {
            StringBuilder text = new StringBuilder($"Players in the guild: {Name}");
            foreach (var item in list)
            {
                text.Append($"\n{item}");
            }

            return text.ToString();
        }

    }
}
